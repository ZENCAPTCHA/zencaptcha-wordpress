document.addEventListener("DOMContentLoaded", function () {
    window.html_forms.on('submitted', function(formElement) {
        zencap.reset();
    });
});